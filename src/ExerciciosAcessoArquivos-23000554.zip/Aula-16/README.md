# Exercícios de Acesso a Arquivos de Texto em Java

## ECM251 - Linguagens de Programação I
**Professor:** Evandro  
**Aula:** 16 - Acesso a Arquivo de Texto em Java

---

Nome: Felipe Fazio da Costa.
RA: 23.00055-4.
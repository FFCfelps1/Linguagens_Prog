/*
 * Imprimir na tela o produto de todos os números de 120 a 300;
 */

public class ex_7 {
    public static void main(String[] args) {
        int var = 120;
        do {
                System.out.println("valor 1:    " + var);
            var += 1;
            
        } while (var < 301);
    }
}
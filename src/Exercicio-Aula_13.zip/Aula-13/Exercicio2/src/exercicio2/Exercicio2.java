package exercicio2;

public class Exercicio2 {

    public static void main(String[] args) {
        RelogioTela tela = new RelogioTela();
    }
    
}

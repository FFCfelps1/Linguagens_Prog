
package exemplo;


public class Exemplo {

    public static void main(String[] args) {
        TesteCalculadora tela = new TesteCalculadora();
    }
    
}

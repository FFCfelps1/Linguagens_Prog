/*Altere o código do Exercício 1, anterior a este, para que, ao
 * invés de apresentar os resultados em tela, apresente-os
 * através da geração dos respectivos arquivos texto
 * texto_cifrada.txt e texto_decifrado.txt, para serem lidos
 * através do aplicativo “Bloco de Notas” do Windows, ou
 * equivalente em uma IDE; e
 * 
 * • Altere o código da classe CryptoDummy.java, dada em anexo,
 * para que realize um algoritmo de criptografia diferente, de sua
 * própria autoria;
 * 
 * • Teste-o e verifique seu funcionamento e grau de segurança,
 * junto a um colega, desconhecedor do algoritmo elaborado.
 */
package ex1;
/*
 * Altere o código fornecido para construir um aplicativo que, ao
 * invés de receber o texto claro diretamente do código em Java
 * (em hardcode), possa fazê-lo através da leitura direta de um
 * arquivo de texto (.txt), gerado pelo aplicativo “Bloco de Notas”
 * do Windows, ou equivalente em uma IDE;
 */

 
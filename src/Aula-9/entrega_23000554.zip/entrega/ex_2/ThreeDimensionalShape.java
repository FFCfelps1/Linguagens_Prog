public abstract class ThreeDimensionalShape extends Shape {
    public abstract double getVolume();
    public abstract double getSurfaceArea();
}
